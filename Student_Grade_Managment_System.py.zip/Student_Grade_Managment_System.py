import json
import os

# store file name
DATA_FILE = "students_data.json"

# student blueprint
class Student:
    def __init__(self, sid, name, grades):
        self.sid = sid
        self.name = name
        self.grades = grades

    def get_average(self):
        if len(self.grades) == 0:
            return 0
        return sum(self.grades) / len(self.grades)

    def get_highest(self):
        if self.grades:
            return max(self.grades)
        return None

    def get_lowest(self):
        if self.grades:
            return min(self.grades)
        return None

    def to_dict(self):
        return {
            "sid": self.sid,
            "name": self.name,
            "grades": self.grades
        }

    @staticmethod
    def from_dict(data):
        return Student(data["sid"], data["name"], data["grades"])

# get student list from file
def load_students():
    students = []
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            stuff = json.load(f)
            for thing in stuff:
                s = Student.from_dict(thing)
                students.append(s)
    return students

# save list to file
def save_students(data):
    out = []
    for s in data:
        out.append(s.to_dict())
    with open(DATA_FILE, "w") as f:
        json.dump(out, f, indent=2)

# main list
student_list = load_students()

def add_student():
    if len(student_list) >= 20:
        print("Sorry, can't add more than 20 students.")
        return

    sid = input("Student ID: ")
    for s in student_list:
        if s.sid == sid:
            print("This ID is already taken.")
            return

    name = input("Student name: ")
    try:
        count = int(input("How many grades? (1 to 5): "))
    except:
        print("Not a number.")
        return

    if count < 1 or count > 5:
        print("Grade count should be from 1 to 5.")
        return

    g = []
    for i in range(count):
        try:
            grade = float(input("Enter grade " + str(i+1) + ": "))
            g.append(grade)
        except:
            print("That wasn't a number.")
            return

    student_list.append(Student(sid, name, g))
    save_students(student_list)
    print("Added and saved.")

def search_student():
    sid = input("Enter ID to search: ")
    found = False
    for s in student_list:
        if s.sid == sid:
            print("Found student:")
            print("ID:", s.sid)
            print("Name:", s.name)
            print("Grades:", s.grades)
            print("Average:", s.get_average())
            print("Highest:", s.get_highest())
            print("Lowest:", s.get_lowest())
            found = True
            break
    if not found:
        print("Student not found.")

def delete_student():
    sid = input("ID to delete: ")
    for i in range(len(student_list)):
        if student_list[i].sid == sid:
            del student_list[i]
            save_students(student_list)
            print("Deleted.")
            return
    print("No student found with that ID.")

def class_stats():
    all_grades = []
    for s in student_list:
        all_grades.extend(s.grades)

    if len(all_grades) == 0:
        print("No grades yet.")
        return

    print("Class average:", round(sum(all_grades)/len(all_grades), 2))
    print("Top grade:", max(all_grades))
    print("Lowest grade:", min(all_grades))

def main():
    while True:
        print("\n---- Grade System ----")
        print("1. Add Student")
        print("2. Search Student")
        print("3. Class Stats")
        print("4. Delete Student")
        print("5. Quit")
        choice = input("Pick an option: ")

        if choice == "1":
            add_student()
        elif choice == "2":
            search_student()
        elif choice == "3":
            class_stats()
        elif choice == "4":
            delete_student()
        elif choice == "5":
            print("Bye!")
            break
        else:
            print("Not valid.")

if __name__ == "__main__":
    main()
